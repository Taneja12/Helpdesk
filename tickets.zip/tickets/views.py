from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.contrib.auth import get_user_model

from .models import Ticket
from .serializers import (
    TicketSerializer,
    AssignTicketSerializer,
    AgentStatusUpdateSerializer,
)
from .permissions import TicketAccessPermission, IsAdminRole, CanCreateTicket
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator


User = get_user_model()


# USER: Create & list their own tickets
@method_decorator(csrf_exempt, name='dispatch')

class TicketListCreateView(generics.ListCreateAPIView):
    serializer_class = TicketSerializer
    permission_classes = [IsAuthenticated, CanCreateTicket]

    def get_queryset(self):
        user = self.request.user
        if user.role == "admin":
            return Ticket.objects.all()
        elif user.role == "agent":
            return Ticket.objects.filter(assigned_to=user)
        return Ticket.objects.filter(created_by=user)
    

@method_decorator(csrf_exempt, name='dispatch')

class TicketDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = TicketSerializer
    queryset = Ticket.objects.all()
    permission_classes = [IsAuthenticated, TicketAccessPermission]

    def perform_destroy(self, instance):
        # Only admins can delete tickets
        if self.request.user.role != "admin":
            raise PermissionError("Only admins can delete tickets.")
        instance.delete()

@method_decorator(csrf_exempt, name='dispatch')
class AssignTicketView(generics.GenericAPIView):
    serializer_class = AssignTicketSerializer
    permission_classes = [IsAuthenticated, IsAdminRole]

    def post(self, request, pk):
        ticket = Ticket.objects.get(pk=pk)
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        agent_username = serializer.validated_data["agent_username"]
        agent = User.objects.get(username=agent_username)

        ticket.assigned_to = agent
        ticket.status = Ticket.STATUS_IN_PROGRESS
        ticket.save()

        return Response({
            "message": "Ticket assigned successfully",
            "assigned_to": agent.username
        })

@method_decorator(csrf_exempt, name='dispatch')
class AgentUpdateStatusView(generics.GenericAPIView):
    serializer_class = AgentStatusUpdateSerializer
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        ticket = Ticket.objects.get(pk=pk)
        self.check_object_permissions(request, ticket)

        # Strictly allow only "status"
        if "status" not in request.data:
            return Response({"error": "Status field is required"}, status=400)

        data = {"status": request.data["status"]}

        serializer = self.get_serializer(ticket, data=data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response({"message": "Status updated"})
