from django.urls import path
from .views import (
    TicketListCreateView,
    TicketDetailView,
    AssignTicketView,
    AgentUpdateStatusView,
)

urlpatterns = [
    path("tickets/", TicketListCreateView.as_view()),
    path("tickets/<int:pk>/", TicketDetailView.as_view()),
    path("tickets/<int:pk>/assign/", AssignTicketView.as_view()),
    path("tickets/<int:pk>/status/", AgentUpdateStatusView.as_view()),
]
