from rest_framework import viewsets, permissions
from .models import Comment
from .serializers import CommentSerializer
from tickets.models import Ticket

class CommentViewSet(viewsets.ModelViewSet):
    serializer_class = CommentSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        ticket_id = self.kwargs['ticket_id']
        return Comment.objects.filter(ticket_id=ticket_id).order_by('-created_at')

    def perform_create(self, serializer):
        ticket_id = self.kwargs['ticket_id']
        serializer.save(ticket_id=ticket_id, user=self.request.user)
